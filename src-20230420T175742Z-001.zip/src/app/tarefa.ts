export class Tarefa {
  id: number;
  tituto: string = '';
  concluida: boolean;

  constructor(id: number, titulo: string, concluida: boolean) {
    this.id = id;
    this.tituto = titulo;
    this.concluida = concluida;
  }

  inserir(): void{
    this.id
  }
  listar(): void{

  }
  editar(): void{

  }
  remover(): void{

  }
}
let tarefa = new Tarefa(id: number, titulo: string, concluida: boolean){
  id = 222,
  titulo = 'Estudar Angular',
  concluida = false;
}
